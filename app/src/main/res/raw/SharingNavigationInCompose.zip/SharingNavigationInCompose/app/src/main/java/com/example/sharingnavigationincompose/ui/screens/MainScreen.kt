package com.example.sharingnavigationincompose.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay


@Composable
fun MainScreenComposable(
    dashboardActivityViewModel: DashboardActivityViewModel
) {

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        val context = LocalContext.current

        TextField(value = dashboardActivityViewModel.name.value, onValueChange = {
            dashboardActivityViewModel.name.value = it
        })
        Spacer(modifier = Modifier.height(10.dp))
        TextField(value = dashboardActivityViewModel.email.value, onValueChange = {
            dashboardActivityViewModel.email.value = it
        })

        Spacer(modifier = Modifier.height(10.dp))
        Button(onClick = {
            val isValid = dashboardActivityViewModel.verifyFields(
                dashboardActivityViewModel.name.value,
                dashboardActivityViewModel.email.value
            )
            if (isValid) {
                (context as MainActivity).checkPermissions()
            } else {
                Toast.makeText(context, "Please provide correct data", Toast.LENGTH_SHORT).show()
            }
        }) {
            Text(text = "Select File And upload document")
        }



        LaunchedEffect(key1 = dashboardActivityViewModel.isError.value, block = {
            delay(3000)
            dashboardActivityViewModel.isError.value = false
        })
        AnimatedVisibility(visible = dashboardActivityViewModel.isError.value) {
            Text(dashboardActivityViewModel.error.value, color = Color.Red)
        }
    }
}