package com.example.sharingnavigationincompose.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.sharingnavigationincompose.ui.screens.DashboardActivityViewModel
import com.example.sharingnavigationincompose.ui.screens.MainScreenComposable
import com.example.sharingnavigationincompose.ui.screens.SuccessPage

@Composable
fun MainApplicationNavigation(
    navHostController: NavHostController,
    dashboardActivityViewModel: DashboardActivityViewModel
) {

    NavHost(navController = navHostController, startDestination = Routes.HOME_DASHBOARD) {
        composable(route = Routes.HOME_DASHBOARD) {
            MainScreenComposable(
                dashboardActivityViewModel = dashboardActivityViewModel
            )
        }

        composable(route = Routes.SuccessPage) {
            SuccessPage(
                dashboardActivityViewModel = dashboardActivityViewModel
            )
        }
    }
}