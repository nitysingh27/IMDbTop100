package com.example.sharingnavigationincompose.ui.screens

import android.text.TextUtils
import android.util.Log
import android.util.Patterns
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.example.sharingnavigationincompose.retrofit.DocumentRepository
import com.example.sharingnavigationincompose.ui.navigation.Routes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

@HiltViewModel
class DashboardActivityViewModel
@Inject
constructor(
    private val documentRepository: DocumentRepository
) : ViewModel() {

    val isError =
        mutableStateOf(false)

    val error =
        mutableStateOf("")

    var link = mutableStateOf("")
    var documentId = ""
    var agreementStatus =  mutableStateOf("")
    var navHostController: NavHostController? = null
    val name = mutableStateOf("")
    val email = mutableStateOf("")

    fun verifyFields(name: String, email: String): Boolean {
        return if (name.isEmpty() || email.isEmpty()) {
            false
        } else {
            if (email.contains("@")) {
                email.isEmailValid()
            } else {
                isValidMobile(email)
            }
        }
    }

    private fun String.isEmailValid(): Boolean {
        return !TextUtils.isEmpty(this) && Patterns.EMAIL_ADDRESS.matcher(this)
            .matches()
    }


    private fun isValidMobile(phone: String): Boolean {
        return Patterns.PHONE.matcher(phone).matches()
    }


    var pdfClickFun: ((Unit) -> (Unit))? = null
    var screenName = "Home"


    fun uploadDocument(
        fileName: String,
        fileData: String,
        error: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = documentRepository.uploadPdfDocument(
                    email.value,
                    name.value,
                    "assignment",
                    fileName,
                    fileData
                )
                if (response?.agreement_status?.isNotEmpty() == true) {
                    documentId = response.id
                    viewModelScope.launch(Dispatchers.Main) {
                        navHostController?.navigate(Routes.SuccessPage)
                    }
                }
            } catch (e: Exception) {
                error?.invoke(e.message.toString())
            }
        }
    }

    fun getDocumentDetails(
        documentId: String,
        showFile: ((File) -> Unit)? = null,
        error: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = documentRepository.retrieveDocumentDetails(
                    documentId
                )
                if (response?.id?.isNotEmpty() == true) {
                    agreementStatus.value = response.agreement_status
                    downloadPdfFile(
                        response.id,
                        showFile,
                        error
                    )
                }
            } catch (e: Exception) {
              error?.invoke(e.message.toString())
            }
        }
    }

    fun downloadPdfFile(
        documentId: String,
        showFile: ((File) -> Unit)? = null,
        error: ((String) -> Unit)? = null
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = documentRepository.downloadPdfFile(
                    documentId
                )
                if (response != null) {
                    showFile?.invoke(response)
                }
            } catch (e: Exception) {
              error?.invoke(e.message.toString())
            }
        }
    }
}