package com.example.sharingnavigationincompose.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun SuccessPage(dashboardActivityViewModel: DashboardActivityViewModel) {

    val context = LocalContext.current
    val isError = remember {
        mutableStateOf(false)
    }
    val error = remember {
        mutableStateOf("")
    }
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(modifier = Modifier) {
            Text(text = "DID : ")
            Text(text = dashboardActivityViewModel.documentId)
        }
        Spacer(modifier = Modifier.height(10.dp))
        if (dashboardActivityViewModel.agreementStatus.value.isNotEmpty()) {
            Row(modifier = Modifier) {
                Text(text = "agreementStatus : ")
                Text(text = dashboardActivityViewModel.agreementStatus.value)

            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Button(onClick = {
            dashboardActivityViewModel.getDocumentDetails(dashboardActivityViewModel.documentId,
                showFile = {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.fromFile(it))
                    (context as MainActivity).startActivity(intent)
                },
                error = {
                    isError.value = true
                    error.value = it
                })
        }) {
            Text(
                text = if (!dashboardActivityViewModel.agreementStatus.value.isNotEmpty()) {
                    "Retrieve Document"
                } else {
                    "Download document"
                }
            )
        }

        LaunchedEffect(key1 = isError.value, block = {
            delay(3000)
            isError.value = false
        })
        AnimatedVisibility(visible = isError.value) {
            Text(error.value, color = Color.Red)
        }
    }
}