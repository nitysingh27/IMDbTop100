package com.example.sharingnavigationincompose.ui.navigation

object Routes {
    val HOME_DASHBOARD = "HOME_DASHBOARD"
    val SuccessPage = "SuccessPage"
}