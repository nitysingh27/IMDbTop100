package com.example.sharingnavigationincompose.retrofit

data class SigningParty(
    var identifier: String = "",
    var name: String = "",
    var reason: String = "",
    var signature_type: String = "",
    var status: String = "",
    var type: String = ""
)