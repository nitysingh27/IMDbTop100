package com.example.sharingnavigationincompose.retrofit

data class Signer(
    var identifier: String = "",
    var name: String = "",
    var reason: String = ""
)